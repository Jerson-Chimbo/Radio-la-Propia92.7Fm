<?php
use aplication\Utiles;
define('DBNAME','book');
define('USER','root');
define('PASSWORD', 'barcelona2012');
